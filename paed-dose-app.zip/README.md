# Paed Dose

Offline paediatric dose index for Android. Enter a child's weight (or a newborn's weight, gestational age and age in days) and read the dose per kg, the maximum dose and the volume for common formulations. Drugs can be saved, and each has a notes box. Saved drugs and notes stay on the phone.

Doses are a starter list from open sources and must be checked against your formulary, BNFC or WHO before prescribing.

## Get the APK
Every push to `main` builds the app on GitHub Actions and attaches `PaedDose.apk` to the **latest** release. Open the Releases page on your phone and install it.

## Edit the doses
All content lives in `app/src/main/assets/www/index.html`. Change it, commit, and a new APK builds in a few minutes.

## Signing
`paeddose.jks` is a fixed key so each build installs over the last one and keeps saved notes. It is for sideloading only, not for Play Store publishing.
